const produtos = [
  { nome: "Maçã Gala", preco: 4.99, tipo: "Fruta", estoque: 120, perecivel: true },
  { nome: "Arroz Tipo 1", preco: 24.50, tipo: "Grão", estoque: 80, perecivel: false },
  { nome: "Leite Integral 1L", preco: 5.49, tipo: "Laticínio", estoque: 60, perecivel: true },
  { nome: "Sabonete Dove", preco: 3.99, tipo: "Higiene Pessoal", estoque: 200, perecivel: false },
  { nome: "Frango Congelado (1kg)", preco: 13.90, tipo: "Carnes", estoque: 45, perecivel: true },
  { nome: "Papel Higiênico c/ 12 rolos", preco: 16.75, tipo: "Limpeza", estoque: 90, perecivel: false },
  { nome: "Shampoo Pantene 400ml", preco: 18.90, tipo: "Higiene Pessoal", estoque: 50, perecivel: false },
  { nome: "Tomate Italiano", preco: 6.25, tipo: "Legume", estoque: 100, perecivel: true },
  { nome: "Café Torrado e Moído 500g", preco: 19.90, tipo: "Bebida", estoque: 70, perecivel: false },
  { nome: "Iogurte Natural 170g", preco: 2.75, tipo: "Laticínio", estoque: 85, perecivel: true },
  { nome: "Feijão Carioca 1kg", preco: 8.60, tipo: "Grão", estoque: 110, perecivel: false },
  { nome: "Água Mineral 1,5L", preco: 2.30, tipo: "Bebida", estoque: 300, perecivel: false },
  { nome: "Presunto Fatiado 200g", preco: 9.80, tipo: "Frios", estoque: 40, perecivel: true },
  { nome: "Cerveja Pilsen 350ml", preco: 3.20, tipo: "Bebida Alcoólica", estoque: 150, perecivel: false },
  { nome: "Alface Crespa", preco: 2.20, tipo: "Verdura", estoque: 70, perecivel: true },
  { nome: "Detergente Líquido 500ml", preco: 2.90, tipo: "Limpeza", estoque: 100, perecivel: false },
  { nome: "Óleo de Soja 900ml", preco: 6.10, tipo: "Cozinha", estoque: 95, perecivel: false },
  { nome: "Pão de Forma Integral", preco: 7.45, tipo: "Panificação", estoque: 60, perecivel: true },
  { nome: "Chocolate ao Leite 100g", preco: 5.80, tipo: "Doce", estoque: 130, perecivel: false },
  { nome: "Banana Nanica", preco: 3.10, tipo: "Fruta", estoque: 140, perecivel: true }
];

export default produtos;