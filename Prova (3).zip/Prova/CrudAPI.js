class CrudAPI {
    constructor() {
      // Array de pedidos fixos: cada objeto possui { id, cliente }
      this.pedidos = [
        { id: 1, cliente: 'João Silva' },
        { id: 2, cliente: 'Maria Oliveira' },
        { id: 3, cliente: 'Pedro Santos' },
        { id: 4, cliente: 'Ana Costa' },
        { id: 5, cliente: 'Carlos Souza' }
      ];
  
      // Array de itens fixos para os pedidos: cada objeto possui { id, pedido_id, produto }
      this.pedidoProdutos = [
        // Pedido 1 (3 itens)
        { id: 1, pedido_id: 1, produto: "Notebook", valor: 3000},
        { id: 2, pedido_id: 1, produto: "Celular", valor: 1200},
        { id: 3, pedido_id: 1, produto: "Teclado", valor: 42.50},
        
        // Pedido 2 (4 itens)
        { id: 4, pedido_id: 2, produto: "Mouse" , valor: 32.50},
        { id: 5, pedido_id: 2, produto: "Monitor", valor: 850.30},
        { id: 6, pedido_id: 2, produto: "Tablet", valor: 900 },
        { id: 7, pedido_id: 2, produto: "Impressora", valor: 650 },
        
        // Pedido 3 (5 itens)
        { id: 8, pedido_id: 3, produto: "Cadeira", valor: 380.80 },
        { id: 9, pedido_id: 3, produto: "Mesa", valor: 780.20},
        { id: 10, pedido_id: 3, produto: "Relógio", valor: 8.40},
        { id: 11, pedido_id: 3, produto: "Notebook", valor: 3000},
        { id: 12, pedido_id: 3, produto: "Celular", valor: 1200},
        
        // Pedido 4 (6 itens)
        { id: 13, pedido_id: 4, produto: "Tablet", valor: 900 },
        { id: 14, pedido_id: 4, produto: "Monitor", valor: 850.30 },
        { id: 15, pedido_id: 4, produto: "Teclado", valor: 42.50 },
        { id: 16, pedido_id: 4, produto: "Mouse" , valor: 32.50},
        { id: 17, pedido_id: 4, produto: "Impressora", valor: 650 },
        { id: 18, pedido_id: 4, produto: "Cadeira", valor: 380.80 },
        
        // Pedido 5 (3 itens)
        { id: 19, pedido_id: 5, produto: "Mesa", valor: 780.20 },
        { id: 20, pedido_id: 5, produto: "Relógio", valor: 8.40 },
        { id: 21, pedido_id: 5, produto: "Notebook" , valor: 3000}
      ];
  
      // Configuração dos atributos para autoincremento dos IDs
      this.proximoIdPedido = 6;
      this.proximoIdPedidoProduto = 22;
    }
  
    // Método assíncrono para cadastrar um novo pedido
    async cadastrarPedido(cliente) {
      return new Promise((resolve) => {
        setTimeout(() => {
          const pedido = { id: this.proximoIdPedido, cliente };
          this.proximoIdPedido++;
          this.pedidos.push(pedido);
          resolve(pedido);
        }, 10);
      });
    }
  
    // Método assíncrono para listar todos os pedidos
    async listarPedidos() {
      return new Promise((resolve) => {
        setTimeout(() => {
          resolve([...this.pedidos]);
        }, 10);
      });
    }
  
    // Método assíncrono para cadastrar um novo item de pedido
    async cadastrarPedidoProduto(produto) {
      return new Promise((resolve) => {
        setTimeout(() => {
          const pedidoProduto = { id: this.proximoIdPedidoProduto, ...produto };
          this.proximoIdPedidoProduto++;
          this.pedidoProdutos.push(pedidoProduto);
          resolve(pedidoProduto);
        }, 10);
      });
    }
  
    // Método assíncrono para listar todos os itens de pedido
    async listarPedidoProdutos() {
      return new Promise((resolve) => {
        setTimeout(() => {
          resolve([...this.pedidoProdutos]);
        }, 10);
      });
    }
  
    // Método assíncrono para ler um pedido pelo ID
    async lerPedidoPorId(id) {
      return new Promise((resolve) => {
        setTimeout(() => {
          const pedido = this.pedidos.find(p => p.id === id);
          resolve(pedido);
        }, 10);
      });
    }
  
    // Método assíncrono para ler um item de pedido pelo ID
    async lerPedidoProdutoPorId(id) {
      return new Promise((resolve) => {
        setTimeout(() => {
          const pedidoProduto = this.pedidoProdutos.find(pp => pp.id === id);
          resolve(pedidoProduto);
        }, 10);
      });
    }
  }
  
  export default new CrudAPI();